# Balaita Cosmin Neculai grupa 141
# Spataru Mara Andreea grupa 141
def load_file(file_name): #functia de load a fisierului
    f = open(file_name, "r")
    d = {} #dictionar ca la dfa
    ok = 0
    start = []
    final = []
    alfabet = [] #alfabetul LA-ului
    for line in f:
        line = line.strip()
        if line and line[0] != "#": #ignoram comentariile si liniile goale
            if line not in d and ok == 0: #luam capul de sectiune (Transitions, Sigma, States, ListAlphabet)
                d[line] = []
                section = line
                ok += 1
            else:
                if line == "End": #sarim peste sfarsitul sectiunilor
                    ok = 0
                else:
                    if section == "Sigma": #daca am ajuns in sectiunea sigma adaugam in dictionar valorile
                        d[section].append(line)
                    elif section == "States": #daca suntem la sectiunea states avem 3 cazuri
                        if len(line.split(',')) == 3: #exista 3 caractere (q0,S,F) deci starea e si de start si de final
                            d[section].append(line.split(',')[0])
                            start.append(line.split(',')[0])
                            final.append(line.split(',')[0])
                        elif len(line.split(',')) == 2: #exista 2 caractere (q0,S sau q0,F) deci verificam daca e ori stare de final ori de start
                            d[section].append(line.split(',')[0])
                            if line.split(',')[1] == 'S':
                                start.append(line.split(',')[0])
                            elif line.split(',')[1] == 'F':
                                final.append(line.split(',')[0])
                        else:
                            d[section].append(line) #daca lg e 1 atunci dam append direct starii
                    elif section == "ListAlphabet": #daca ajungem la sectiunea cu alfabetul listei, dam append caracterelor
                        alfabet.append(line)
                        d[section].append(line)
                    elif section == "Transitions": #daca ajungem la sectiunea tranzitiilor dam append intregii linii
                        d[section].append(line)
    f.close()
    return d, start, final, alfabet #returnam tot dictionarul, lista starilor de start, lista cu starile finale si alfabetul pt LA


def verify_file(d): #functia de verificare a fisierului
    valid = True #pornim presupunand ca e ok
    if (len(start) != 1): #daca exista mai multe stari de start returnam False
        valid = False
        return valid
    for t in d["Transitions"]:
        tranzitii = t.split(',')
        if tranzitii[0] not in d["States"]: #daca primul elem din tranzitii nu e in States returnam false
            valid = False
            return valid
        if tranzitii[1] not in d["Sigma"]: #daca al doilea elem din tranzitii nu e in Sigma returnam false
            valid = False
            return valid
        if tranzitii[2] not in d["ListAlphabet"]: #daca al 3 lea elem din tranzitii nu e in alfabetul listei returnam false
            valid = False
            return valid
        if tranzitii[3] not in d["States"]: #daca al 4 lea elem nu e in states returnam false ptc aia e starea in care noi va trb sa mergem
            valid = False
            return valid
    return valid #la sf daca totul a fost ok se va returna True


def simulare(d, next, final, alfabet, i): #simularea unui LA
    found_transition = False  #verificam daca tranzitia exista pt caracterul curent
    for tranzitii in d["Transitions"]: #parcurgem fiecare tranzitie din dictionar
        tranzitii = tranzitii.split(',') #dam split in parti separate
        if tranzitii[0] == next and tranzitii[1] == istring[i]: #daca primul elem din tranzitie e starea curenta(next) si al doilea elem
            found_transition = True                             #este egal cu caracterul curent citit din sirul din input
            next = tranzitii[3]                                 #al patrulea elem este starea in care urmeaza sa mergem
            if tranzitii[2] in alfabet:
                if tranzitii[4] != "": #daca al 5 lea elem nu este null inseamna ca trebuie sa il stergem din alfabetul listei
                    remove = tranzitii[4]
                    for r in remove:
                        alfabet.remove(r)
                if tranzitii[5] != "": #daca ultimul element nu este null inseamna ca trebuie sa il adaugam alfabetului listei atasate
                    alfabet.append(tranzitii[5])
    if not found_transition: #daca cumva nu am gasit nicio tranzitie care sa se potriveasca pt caracterul curent, returnam
        return "Cuvant neacceptat", alfabet  #ca nu e acceptat cuvantul

    if i+1 < len(istring): #daca exista si i+1 in sirul dat ca input
        i += 1
        return simulare(d, next, final, alfabet, i)  #apelam recursiv functia
    else: #altfel verificam daca cuvantul e acceptat
        if next in final: #daca ce a ramas in next(ultima stare prin care am trecut) se afla in multimea de stari finale atunci e ok
            return "Cuvant acceptat", alfabet
        else:
            return "Cuvant neacceptat", alfabet #altfel returnam ca nu e acceptat


d, start, final, alfabet = load_file("file.in") #apelam functia de incarcare a fisierului
print(d) #dictionarul (tip DFA)
print(start) #stare start
print(final) #stari finale
print(alfabet) #alfabetul listei
print(verify_file(d)) #apelam verificarea fisierului
next = start[0] #luam starea de start si o punem in next ca sa creem primul apel al functiei simulare()
istring = input("Introduceti sirul: ") #sirul input
i = 0 #index pt string
result, updated_alfabet = simulare(d, next, final, alfabet, i) #result=acceptat/neacceptat si updated_alfabet e alfabetul listei dupa simulare
print(result)
print("Alfabet:",updated_alfabet)
print("Alfabet cu elemente distincte:",set(updated_alfabet))